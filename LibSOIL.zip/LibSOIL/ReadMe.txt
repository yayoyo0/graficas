﻿========================================================================
    BIBLIOTECA ESTÁTICA: LibSOIL Información general del proyecto
========================================================================

AppWizard ha creado este proyecto de biblioteca LibSOIL.

No se crearon archivos de código fuente como parte del proyecto.


LibSOIL.vcxproj
    Éste es el archivo de proyecto principal para los proyectos de VC++ generados mediante un Asistente para aplicaciones. Contiene información acerca de la versión de Visual C++ con la que se generó el archivo, así como información acerca de las plataformas, configuraciones y características del proyecto seleccionadas en el Asistente para aplicaciones.

LibSOIL.vcxproj.filters
    Éste es el archivo de filtros para los proyectos de VC++ generados mediante un asistente para aplicaciones. Contiene información acerca de la asociación entre los archivos del proyecto y los filtros. Esta asociación se usa en el IDE para mostrar la agrupación de archivos con extensiones similares bajo un nodo específico (por ejemplo, los archivos ".cpp" se asocian con el filtro"Archivos de código fuente").

/////////////////////////////////////////////////////////////////////////////
Otras notas:

El asistente para aplicaciones utiliza comentarios "TODO:" para indicar las partes del código fuente que tendrá que agregar o personalizar.

/////////////////////////////////////////////////////////////////////////////
